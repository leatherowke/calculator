let x = 1
let y = 2

// Write your code below this line.

